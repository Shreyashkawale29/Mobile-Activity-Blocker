package com.example.mobileactivityblocker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;

import android.os.Build;

import android.os.Bundle;

import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide(); //This Line hides the Action Bar

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_main);

        TextView gotosignup=findViewById(R.id.signup);
        Button btnlogin=findViewById(R.id.btnlogin);

        EditText login_edtEmail=findViewById(R.id.login_edtEmail);
        EditText login_edtPass=findViewById(R.id.login_edtPass);


        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (login_edtEmail.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Please Enter Your EMail",Toast.LENGTH_SHORT).show();
                }

                if (login_edtPass.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Please Enter Your Password",Toast.LENGTH_SHORT).show();
                }

                FirebaseAuth firebaseAuth=FirebaseAuth.getInstance();

                if (!(login_edtEmail.getText().toString().isEmpty() && login_edtEmail.getText().toString().isEmpty() && login_edtPass.getText().toString().isEmpty())){

                    firebaseAuth.signInWithEmailAndPassword(login_edtEmail.getText().toString(),login_edtPass.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                Intent loginsuccess=new Intent(MainActivity.this,DashBoard.class);
                                startActivity(loginsuccess);
                            }
                            else {
                                Toast.makeText(getApplicationContext(), task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });


        gotosignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent signup=new Intent(MainActivity.this,SignupActivity.class);
                startActivity(signup);

            }
        });
        firebaseDatabase.getReference().child("Node1").child("Node2").setValue("Nodevalue");

        checkOverlayPermission();

        //startService();





    }









    // method to ask user to grant the Overlay permission

    public void checkOverlayPermission(){



        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (!Settings.canDrawOverlays(this)) {

                // send user to the device settings

                Intent myIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);

                startActivity(myIntent);

            }

        }

    }




}